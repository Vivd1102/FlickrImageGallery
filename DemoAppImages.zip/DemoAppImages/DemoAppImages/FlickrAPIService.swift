//
//  NetworkManager.swift
//  DemoAppImages
//
//  Created by apple on 13/04/25.
//

import Foundation

class FlickrAPIService {
    static let shared = FlickrAPIService()
    
    private init() {}

    func fetchPhotos(completion: @escaping ([Photo]) -> Void) {
        let urlString = "https://www.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1"
        guard let url = URL(string: urlString) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                completion([])
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let items = json["items"] as? [[String: Any]] {
                    let photos = items.compactMap { dict -> Photo? in
                        if let media = dict["media"] as? [String: String],
                           let urlString = media["m"],
                           let url = URL(string: urlString) {
                            return Photo(imageURL: url)
                        }
                        return nil
                    }
                    completion(photos)
                } else {
                    completion([])
                }
            } catch {
                completion([])
            }
        }.resume()
    }
}

