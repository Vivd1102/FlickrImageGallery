//
//  FlickrImage.swift
//  DemoAppImages
//
//  Created by apple on 13/04/25.
//

import Foundation

struct Photo {
    let imageURL: URL
}

