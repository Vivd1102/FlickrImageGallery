//
//  PhotoGalleryViewController.swift
//  DemoAppImages
//
//  Created by apple on 13/04/25.
//

import Foundation
import UIKit

class PhotoGalleryViewController: UICollectionViewController {

    private var photos: [Photo] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Flickr Gallery"
        collectionView.backgroundColor = .white
        collectionView.register(PhotoCollectionViewCell.self, forCellWithReuseIdentifier: PhotoCollectionViewCell.identifier)
        
        fetchPhotos()
    }

    private func fetchPhotos() {
        FlickrAPIService.shared.fetchPhotos { [weak self] photos in
            DispatchQueue.main.async {
                self?.photos = photos
                self?.collectionView.reloadData()
            }
        }
    }

    // MARK: - UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoCollectionViewCell.identifier, for: indexPath) as! PhotoCollectionViewCell
        let photo = photos[indexPath.item]
        cell.configure(with: photo.imageURL)
        return cell
    }
}
